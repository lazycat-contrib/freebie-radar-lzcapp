import assert from "node:assert/strict";
import { test } from "node:test";
import { classify, demoteOfflineCategory, enrichItem, isOfflineWorthy, scoreItem } from "../src/server/enrich/index.ts";
import { cleanText, guessExpiry, normalizeUrl, parseDate, urlKey } from "../src/server/enrich/normalize.ts";

test("URL 规范化：追踪参数、片段、尾斜杠都不影响去重键", () => {
  const a = "https://Example.com/deal/1?utm_source=x&utm_medium=y&b=2#top";
  const b = "https://example.com/deal/1/?b=2";
  assert.equal(normalizeUrl(a), "https://example.com/deal/1?b=2");
  assert.equal(urlKey(a), urlKey(b));
});

test("URL 规范化：不同 query 值仍是不同资源", () => {
  assert.notEqual(urlKey("https://a.com/p?id=1"), urlKey("https://a.com/p?id=2"));
});

test("URL 规范化：保留有意义的 query，去掉 utm_ 前缀的全部参数", () => {
  assert.equal(normalizeUrl("https://a.com/p?utm_campaign=z&page=3&spm=abc"), "https://a.com/p?page=3");
});

test("分类：AI 额度", () => {
  assert.equal(classify("免费领取 GPT-4 API 额度", "").category, "ai");
  assert.equal(classify("Gemini Pro 注册送 10 美元", "").category, "ai");
});

test("分类：影音会员", () => {
  assert.equal(classify("网易云音乐免费领取会员 7 天，需要自取", "").category, "media");
});

test("分类：域名与主机", () => {
  assert.equal(classify("免费 .dev 域名注册一年", "").category, "domain");
});
test("分类：实物福利（线下门店/快闪/现场领取）", () => {
  assert.equal(classify("五大绝美花墙免费打卡，现场可免费领取手幅", "").category, "offline");
  assert.equal(classify("正大附近，粉丝福利，免费送，2束鲜花", "").category, "offline");
  assert.equal(classify("新店开业活动：到店免费领小样，可自提", "").category, "offline");
  // 线上羊毛仍归「实物/优惠」
  assert.equal(classify("京东优惠券满减，包邮到家", "").category, "goods");
  // 新闻里的「现场」不算实物福利
  assert.notEqual(classify("记者现场直击：峰会发布会现场", "").category, "offline");
  // 只有地点词、没有领取动作的资讯/闲聊不算实物福利
  assert.notEqual(classify("51批防火玻璃7批不合格，耐火时间是个问号", "现场抽检").category, "offline");
  assert.notEqual(classify("哥们们 杭州附近的兄弟有吗 我想租个房 给大家一起免费玩有人吗", "").category, "offline");
});

test("分类：实物福利里的资讯/水帖在 enrich 阶段被降级", () => {
  const e = enrichItem(
    {
      externalId: "x",
      url: "https://a.com/offline-news",
      title: "商场门店周末活动回顾",
      summary: "现场排队领取纪念礼品",
    },
    "rss-ithome",
  );
  assert.ok(e);
  assert.notEqual(e.category, "offline");
  assert.equal(e.kind, "info");
});

test("分类：实物福利只收福利（freebie），好价与海外线上促销一律不进", () => {
  // 好价（deal）不是福利
  assert.equal(isOfflineWorthy("Dairy Queen- 2 for $6 cupcakes", "到店自取", "deal"), false);
  // 全英文的海外线上促销不是中文站的实物福利
  assert.equal(
    isOfflineWorthy(
      "6 FREE Walgreens Photo Cards ($24 Value)",
      "use promo code 6PREM at checkout and opt for free same-day pickup",
      "freebie",
    ),
    false,
  );
  // 真·实物福利：中文 + 线下场景 + 领取动作
  assert.equal(isOfflineWorthy("海口博博会，河北博物院礼品免费送", "现场领取", "freebie"), true);
  assert.equal(isOfflineWorthy("新店开业活动：到店免费领小样", "", "freebie"), true);
  assert.equal(demoteOfflineCategory("offline", "deal", "Dairy Queen- 2 for $6 cupcakes", "", "goods"), "goods");
  assert.equal(demoteOfflineCategory("offline", "freebie", "海口博博会，河北博物院礼品免费送", "现场领取"), "offline");
});

test("分类：无关键词落 other", () => {
  assert.equal(classify("今天天气不错", "").category, "other");
});

test("评分：过期资源归零且 keep=false", () => {
  const past = new Date(Date.now() - 86400000).toISOString();
  const enriched = enrichItem(
    { externalId: "x", url: "https://a.com/x", title: "免费领取会员", expiresAt: past },
    "linuxdo-welfare",
  );
  assert.ok(enriched);
  assert.equal(enriched.score, 0);
  assert.equal(enriched.keep, false);
});

test("评分：24 小时内发布明显高于 60 天前", () => {
  const fresh = new Date().toISOString();
  const old = new Date(Date.now() - 60 * 86400000).toISOString();
  const base = { summary: "免费领取", sourceId: "v2ex-free", category: "other" as const, tags: [], expiresAt: null };
  const sFresh = scoreItem({ ...base, title: "免费领取会员", publishedAt: fresh }).score;
  const sOld = scoreItem({ ...base, title: "免费领取会员", publishedAt: old }).score;
  assert.ok(sFresh > sOld + 15, "fresh=" + sFresh + " old=" + sOld);
});

test("评分：求资源类疑问句被压分", () => {
  const p = new Date().toISOString();
  const base = { summary: "", sourceId: "linuxdo-welfare", category: "other" as const, tags: [], expiresAt: null };
  const ask = scoreItem({ ...base, title: "请问有没有免费的 GPT 额度", publishedAt: p }).score;
  const deal = scoreItem({ ...base, title: "免费送 GPT 额度，先到先得", publishedAt: p }).score;
  assert.ok(deal > ask, "deal=" + deal + " ask=" + ask);
});

test("清洗：HTML 转纯文本并截断", () => {
  assert.equal(cleanText("<p>免费&nbsp;领取</p><script>x</script>"), "免费 领取");
  assert.ok(cleanText("a".repeat(500), 10).endsWith("…"));
});

test("时间解析：秒级时间戳与 RFC822", () => {
  assert.equal(parseDate(1794329084), new Date(1794329084 * 1000).toISOString());
  assert.equal(parseDate("Wed, 10 Nov 2026 16:24:46 GMT"), "2026-11-10T16:24:46.000Z");
  assert.equal(parseDate("not a date"), null);
});

test("过期推断：识别月日与相对天数", () => {
  assert.ok(guessExpiry("活动截止 12 月 31 日"));
  assert.ok(guessExpiry("3 天内有效"));
  assert.equal(guessExpiry("没有任何日期"), null);
});

test("AI 二审关闭时（默认配置）全链路正常出结果", () => {
  const enriched = enrichItem(
    { externalId: "y", url: "https://a.com/y", title: "免费领取 7 天会员", publishedAt: new Date().toISOString() },
    "v2ex-free",
  );
  assert.ok(enriched);
  assert.ok(enriched.score >= 40);
  assert.equal(enriched.category, "media");
});

import { isBlocked, matchBlockRules, PRESET_NOISE_PATTERNS, type BlockRule } from "../src/server/enrich/blocklist.ts";
import { extractPrice } from "../src/server/enrich/pricing.ts";

test("价格：free shipping 不算白嫖，100 元不算 0 元", () => {
  const a = extractPrice("13-Oz Cookies $1.96 + Free Shipping", "");
  assert.equal(a.isFree, false);
  assert.ok(a.price && a.price > 10);

  const b = extractPrice("100 元耳机推荐指南", "");
  assert.equal(b.isFree, false);
});

test("价格：免费领与符号前置正常识别", () => {
  assert.equal(extractPrice("Epic 免费领 Flotsam", "").isFree, true);
  assert.equal(extractPrice("新人领 ¥3.5 体验额", "").price, 3.5);
});

test("屏蔽词：关键词、正则与源作用域", () => {
  const rules: BlockRule[] = [
    { id: 1, pattern: "汽车", mode: "keyword", scope: "all", enabled: 1, created_at: "" },
    { id: 2, pattern: "^(请问|求助)", mode: "regex", scope: "all", enabled: 1, created_at: "" },
    { id: 3, pattern: "油价", mode: "keyword", scope: "rss-smzdm", enabled: 1, created_at: "" },
  ];
  assert.equal(isBlocked({ title: "比亚迪汽车调换", source_id: "rss-ithome" }, rules), true);
  assert.equal(isBlocked({ title: "请问哪里领额度", source_id: "linuxdo-welfare" }, rules), true);
  assert.equal(isBlocked({ title: "国际油价跌破 90", source_id: "rss-smzdm" }, rules), true);
  assert.equal(isBlocked({ title: "国际油价跌破 90", source_id: "v2ex-free" }, rules), false);
  assert.equal(matchBlockRules({ title: "Epic 免费领游戏", source_id: "epic-free" }, rules), null);
  assert.ok(PRESET_NOISE_PATTERNS.length >= 10);
});

